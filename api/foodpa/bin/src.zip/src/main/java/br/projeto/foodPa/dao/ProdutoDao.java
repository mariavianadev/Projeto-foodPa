/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.projeto.foodPa.dao;

import java.util.List;
import br.projeto.foodPa.model.Produto;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

/**
 *
 * @author dougl
 */
@RegisterBeanMapper(Produto.class)
public interface ProdutoDao {
    
    @GetGeneratedKeys
    @SqlUpdate("insert into produto (nome, descricao) values (:nome, :descricao)")
    int insert(@BindBean Produto produto);
    
    
    @SqlQuery("select * " +
            " from produto " +
            " where idProduto = :idProduto;")
    Produto get(@Bind("idProduto") int idProduto);

     @SqlQuery("select * " +
            " from produto " +
            " order by nome;")
    List<Produto> getAll();

    @SqlUpdate("update produto" +
           "  set nome = :nome," +
           " descricao = :descricao," +
           "  where id = :id;")
    int update(@BindBean Produto produto);

    
    @SqlUpdate("delete " +
            " from produto " +
            " where id = :id;")
    int delete(@Bind("id") int id);

}